#ifndef NOABILITIESEXCEPTION_H
#define NOABILITIESEXCEPTION_H

#include "GameException.h"

class NoAbilitiesException : public GameException {
public:
    NoAbilitiesException();
};

#endif // NOABILITIESEXCEPTION_H
